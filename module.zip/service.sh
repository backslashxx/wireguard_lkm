#!/usr/bin/env sh
MODDIR="${0%/*}"
desription="description=wireguard.ko for xx kernels"
if [ -f $MODDIR/wg_enable ]; then
	getprop ro.product.name | grep -E 'sunny|mojito' && insmod $MODDIR/mojito/wireguard.ko
	getprop ro.product.name | grep -E 'daisy|sakura|ysl' && insmod $MODDIR/msm8953/wireguard.ko
fi

lsmod | grep wireguard && desription="description=wireguard.ko | status: active ✅"
lsmod | grep wireguard || desription="description=wireguard.ko | status: disabled ❌"
sed -i "s/^description=.*/$desription/g" $MODDIR/module.prop
