#!/usr/bin/env sh
MODDIR="${0%/*}"
desription="description=wireguard.ko for xx kernels"
if [ ${KSU} = true ] || [ ${APATCH} = true ] ; then
	MODDIR=$MODPATH
fi

echo "# insmod wireguard.ko"

( getprop ro.product.name | grep -E 'sunny|mojito' && insmod $MODDIR/mojito/wireguard.ko ) > /dev/null 2>&1 
( getprop ro.product.name | grep -E 'daisy|sakura|ysl' && insmod $MODDIR/msm8953/wireguard.ko ) > /dev/null 2>&1 
lsmod | grep wireguard && desription="description=wireguard.ko | status: active ✅" 
sed -i "s/^description=.*/$desription/g" $MODDIR/module.prop

touch $MODDIR/wg_enable
