# wireguard_lkm
Wireguard LKM for my builds

[Download](https://raw.githubusercontent.com/backslashxx/wireguard_lkm/refs/heads/main/module.zip)
